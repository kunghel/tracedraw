Original CDR27 Gaussian blur parser sample. MIT OR Apache-2.0.

Two original rectangles: dark sharp background and white rectangle with
GaussianBlurEffect, Radius 1500, Resampled 0, Visible 1, Deleted 0, Z_Index 0.
No private source drawing, metadata, fonts or application assets included.
The minimal synthetic container has not been tested in another application.

Reproduction: tracedraw-cli convert gaussian-blur.cdr result.png
Official v0.46.0: sharp white rectangle, no editable FX.
The proposed change: imported editable radius 15.0 and a soft edge.
The after image illustrates TraceDraw rendering, not an independently
verified reference for the exact source application's blur kernel.

Generator: scripts/samples/cdr_gaussian_blur.py in the contribution branch.
